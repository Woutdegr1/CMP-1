<?php 
$current = "index.php";
require_once("includes/header.php"); 
require_once("includes/nav.php"); 
?>
        <div class="container">
             <h1>Hello, Bootstrappers!</h1>
        </div>
<?php require_once("includes/footer.php"); ?>